import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const FireShieldApp());

const red = Color(0xFFE3262E);
const blue = Color(0xFF4FA8FF);
const bg = Color(0xFF060A12);
const panel = Color(0xFF101724);

class FireShieldApp extends StatelessWidget {
  const FireShieldApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Gulf Fire Shield',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: red, brightness: Brightness.dark),
      fontFamily: 'Roboto',
    ),
    home: const Shell(),
  );
}

class Product {
  final String name, desc;
  final IconData icon;
  const Product(this.name, this.desc, this.icon);
}

const products = <Product>[
  Product('Steel Pipes','Reliable piping solutions for fire protection systems.',Icons.linear_scale_rounded),
  Product('Threaded Fittings','Precision fittings for dependable connections.',Icons.settings_input_component_rounded),
  Product('Grooved Fittings','Fast, secure and efficient grooved connections.',Icons.join_inner_rounded),
  Product('Buttweld Fittings','Industrial-grade welded pipe fittings.',Icons.account_tree_rounded),
  Product('Forged Flanges','Heavy-duty flanges for demanding applications.',Icons.circle_outlined),
  Product('Valves','Flow-control solutions for fire protection networks.',Icons.tune_rounded),
  Product('Zone Control Valve Assemblies','Complete zone control solutions.',Icons.dashboard_customize_rounded),
  Product('High-Pressure Steel Fittings','Built for high-pressure applications.',Icons.bolt_rounded),
  Product('Pipe Clamps & Threaded Rods','Secure pipe support and installation hardware.',Icons.build_circle_rounded),
  Product('Fire Protection Accessories','Essential components for complete systems.',Icons.local_fire_department_rounded),
  Product('Hardware & Safety Products','Practical hardware and safety essentials.',Icons.health_and_safety_rounded),
];

Future<void> openUrl(String value) async {
  final uri = Uri.parse(value);
  if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int tab = 0;
  final pages = const [Home(), Products(), About(), Contact()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: AnimatedSwitcher(
      duration: const Duration(milliseconds: 450),
      child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]),
    ),
    bottomNavigationBar: SafeArea(
      child: Container(
        margin: const EdgeInsets.fromLTRB(14,0,14,12),
        decoration: BoxDecoration(
          color: panel.withOpacity(.97),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(.08)),
        ),
        child: NavigationBar(
          backgroundColor: Colors.transparent,
          selectedIndex: tab,
          onDestinationSelected: (i)=>setState(()=>tab=i),
          indicatorColor: red.withOpacity(.18),
          destinations: const [
            NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
            NavigationDestination(icon:Icon(Icons.inventory_2_outlined),selectedIcon:Icon(Icons.inventory_2),label:'Products'),
            NavigationDestination(icon:Icon(Icons.business_outlined),selectedIcon:Icon(Icons.business),label:'About'),
            NavigationDestination(icon:Icon(Icons.phone_outlined),selectedIcon:Icon(Icons.phone),label:'Contact'),
          ],
        ),
      ),
    ),
  );
}

class AnimatedBG extends StatefulWidget {
  final Widget child;
  const AnimatedBG({super.key,required this.child});
  @override State<AnimatedBG> createState()=>_AnimatedBGState();
}
class _AnimatedBGState extends State<AnimatedBG> with SingleTickerProviderStateMixin {
  late AnimationController c;
  @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(seconds:14))..repeat();}
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:c,
    builder:(_,__)=>CustomPaint(painter: ParticlePainter(c.value),child:widget.child),
  );
}
class ParticlePainter extends CustomPainter {
  final double p;
  ParticlePainter(this.p);
  @override void paint(Canvas canvas,Size s){
    for(int i=0;i<42;i++){
      final a=i*19.7;
      final x=((math.sin(a)+1)/2)*s.width;
      final y=(((math.cos(a*.71)+1)/2)*s.height-p*(50+i*2))%s.height;
      final paint=Paint()..color=Colors.white.withOpacity(.025+(i%5)*.012);
      canvas.drawCircle(Offset(x,y),1+(i%3)*.5,paint);
    }
    final glow=Paint()..shader=RadialGradient(colors:[red.withOpacity(.20),Colors.transparent]).createShader(
      Rect.fromCircle(center:Offset(s.width*.82,s.height*.16),radius:s.width*.7));
    canvas.drawCircle(Offset(s.width*.82,s.height*.16),s.width*.7,glow);
    final blueGlow=Paint()..shader=RadialGradient(colors:[blue.withOpacity(.10),Colors.transparent]).createShader(
      Rect.fromCircle(center:Offset(s.width*.05,s.height*.72),radius:s.width*.55));
    canvas.drawCircle(Offset(s.width*.05,s.height*.72),s.width*.55,blueGlow);
  }
  @override bool shouldRepaint(covariant ParticlePainter old)=>old.p!=p;
}

class Page extends StatelessWidget {
  final Widget child;
  const Page({super.key,required this.child});
  @override Widget build(BuildContext context)=>Scaffold(
    body: AnimatedBG(child:SafeArea(child:SingleChildScrollView(
      physics:const BouncingScrollPhysics(),
      padding:const EdgeInsets.fromLTRB(18,16,18,32),child:child))),
  );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState()=>_HomeState();
}
class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  late AnimationController c;
  @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:1200))..forward();}
  @override void dispose(){c.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Page(child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[
        ClipRRect(borderRadius:BorderRadius.circular(14),child:Image.asset('assets/logo.jpg',width:58,height:58,fit:BoxFit.cover)),
        const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('GULF FIRE SHIELD',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.1)),
          Text('TRADING FZE',style:TextStyle(color:red,fontWeight:FontWeight.w800,letterSpacing:1)),
        ])),
        IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'Gulf Fire Shield'),icon:const Icon(Icons.info_outline))
      ]),
      const SizedBox(height:22),
      AnimatedBuilder(animation:c,builder:(_,child)=>Opacity(
        opacity:c.value,child:Transform.translate(offset:Offset(0,25*(1-c.value)),child:child)),child:
        Container(width:double.infinity,padding:const EdgeInsets.fromLTRB(22,28,22,24),
          decoration:BoxDecoration(
            borderRadius:BorderRadius.circular(32),
            gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,
              colors:[Color(0xFF27121A),Color(0xFF121B2A),Color(0xFF090D15)]),
            border:Border.all(color:red.withOpacity(.26)),
            boxShadow:[BoxShadow(color:red.withOpacity(.12),blurRadius:40,spreadRadius:2)]
          ),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Tag('FIRE PROTECTION • INDUSTRIAL SOLUTIONS'),
            const SizedBox(height:18),
            const Text('Protecting\nWhat Matters.',style:TextStyle(fontSize:43,height:1.0,fontWeight:FontWeight.w900,letterSpacing:-1.8)),
            const SizedBox(height:14),
            Text('Reliable equipment trading for fire protection and industrial applications.',
              style:TextStyle(color:Colors.white.withOpacity(.68),height:1.45,fontSize:15)),
            const SizedBox(height:22),
            Row(children:[
              Expanded(child:FilledButton.icon(onPressed:()=>openUrl('https://wa.me/971544462358'),
                icon:const Icon(Icons.chat_rounded),label:const Text('Talk to Sales'),
                style:FilledButton.styleFrom(backgroundColor:red,padding:const EdgeInsets.symmetric(vertical:15)))),
              const SizedBox(width:10),
              Expanded(child:OutlinedButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const Products())),
                style:OutlinedButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:15),side:BorderSide(color:Colors.white.withOpacity(.18))),
                child:const Text('Explore')))
            ])
          ])
        )
      ),
      const SizedBox(height:24),
      const Section('Why Gulf Fire Shield?'),
      const SizedBox(height:12),
      const Row(children:[
        Expanded(child:Metric('11+','Product categories')),
        SizedBox(width:10),Expanded(child:Metric('UAE','Trading base')),
      ]),
      const SizedBox(height:10),
      const Row(children:[
        Expanded(child:Metric('24/7','Enquiry access')),
        SizedBox(width:10),Expanded(child:Metric('B2B','Project focused')),
      ]),
      const SizedBox(height:26),
      const Section('Featured Solutions'),
      const SizedBox(height:12),
      SizedBox(height:190,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:5,
        separatorBuilder:(_,__)=>const SizedBox(width:12),
        itemBuilder:(_,i)=>SizedBox(width:265,child:ProductCard(p:products[i])))),
      const SizedBox(height:24),
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(24),color:blue.withOpacity(.08),
        border:Border.all(color:blue.withOpacity(.18))),child:const Row(children:[
          Icon(Icons.auto_awesome_rounded,color:blue,size:32),SizedBox(width:14),
          Expanded(child:Text('Premium design. Clear product discovery. Fast contact with sales.',
            style:TextStyle(fontWeight:FontWeight.w700,height:1.35)))
      ]))
    ]));
}

class Tag extends StatelessWidget {
  final String text;
  const Tag(this.text,{super.key});
  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:11,vertical:7),
    decoration:BoxDecoration(color:red.withOpacity(.12),borderRadius:BorderRadius.circular(50),border:Border.all(color:red.withOpacity(.25))),
    child:Text(text,style:const TextStyle(color:Color(0xFFFF6670),fontSize:10,fontWeight:FontWeight.w900,letterSpacing:.65)));
}
class Section extends StatelessWidget {
  final String text; const Section(this.text,{super.key});
  @override Widget build(BuildContext context)=>Text(text,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900));
}
class Metric extends StatelessWidget {
  final String n,l; const Metric(this.n,this.l,{super.key});
  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(17),
    decoration:BoxDecoration(color:Colors.white.withOpacity(.045),borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withOpacity(.07))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(n,style:const TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:red)),
      const SizedBox(height:4),Text(l,style:TextStyle(color:Colors.white.withOpacity(.55)))
    ]));
}

class ProductCard extends StatefulWidget {
  final Product p; const ProductCard({super.key,required this.p});
  @override State<ProductCard> createState()=>_ProductCardState();
}
class _ProductCardState extends State<ProductCard> {
  bool pressed=false;
  @override Widget build(BuildContext context)=>GestureDetector(
    onTapDown:(_)=>setState(()=>pressed=true),onTapCancel:()=>setState(()=>pressed=false),
    onTapUp:(_){setState(()=>pressed=false);showModalBottomSheet(context:context,backgroundColor:panel,showDragHandle:true,
      builder:(_)=>Details(p:widget.p));},
    child:AnimatedScale(scale:pressed?.96:1,duration:const Duration(milliseconds:120),child:
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(25),
        gradient:LinearGradient(colors:[red.withOpacity(.13),panel]),
        border:Border.all(color:red.withOpacity(.16))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Container(width:55,height:55,decoration:BoxDecoration(color:red.withOpacity(.11),shape:BoxShape.circle),
            child:Icon(widget.p.icon,color:red,size:30)),
          const Spacer(),
          Text(widget.p.name,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
          const SizedBox(height:6),Text(widget.p.desc,maxLines:2,overflow:TextOverflow.ellipsis,
            style:TextStyle(fontSize:12,color:Colors.white.withOpacity(.53),height:1.35))
        ]))));
}

class Details extends StatelessWidget {
  final Product p; const Details({super.key,required this.p});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(22,6,22,30),
    child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      Container(width:76,height:76,decoration:BoxDecoration(color:red.withOpacity(.12),shape:BoxShape.circle),
        child:Icon(p.icon,color:red,size:42)),
      const SizedBox(height:17),Text(p.name,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),
      const SizedBox(height:9),Text(p.desc,style:TextStyle(color:Colors.white.withOpacity(.62),height:1.5,fontSize:15)),
      const SizedBox(height:18),const Text('Gulf Fire Shield Trading FZE',style:TextStyle(fontWeight:FontWeight.w800)),
      const SizedBox(height:16),FilledButton.icon(onPressed:()=>openUrl('https://wa.me/971544462358'),
        icon:const Icon(Icons.chat),label:const Text('Enquire about this product'),
        style:FilledButton.styleFrom(backgroundColor:red,minimumSize:const Size.fromHeight(50)))
    ]));
}

class Products extends StatelessWidget {
  const Products({super.key});
  @override Widget build(BuildContext context)=>Page(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SizedBox(height:5),const Tag('OUR PRODUCTS'),const SizedBox(height:15),
    const Text('Solutions for\nfire protection.',style:TextStyle(fontSize:36,fontWeight:FontWeight.w900,height:1.03)),
    const SizedBox(height:10),Text('Tap any product to explore it and contact sales.',style:TextStyle(color:Colors.white.withOpacity(.58))),
    const SizedBox(height:22),
    GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:products.length,
      gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:.88),
      itemBuilder:(_,i)=>ProductCard(p:products[i]))
  ]));
}

class About extends StatelessWidget {
  const About({super.key});
  @override Widget build(BuildContext context)=>Page(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SizedBox(height:5),const Tag('ABOUT US'),const SizedBox(height:16),
    const Text('A stronger shield\nfor every project.',style:TextStyle(fontSize:36,fontWeight:FontWeight.w900,height:1.04)),
    const SizedBox(height:14),Text('Gulf Fire Shield Trading FZE supplies equipment and industrial products for fire protection and related applications, with a focus on dependable products and responsive service.',
      style:TextStyle(color:Colors.white.withOpacity(.62),height:1.6,fontSize:15)),
    const SizedBox(height:22),
    const Feature(Icons.verified_rounded,'Quality focused','Product categories selected around practical project requirements.'),
    const Feature(Icons.local_shipping_rounded,'Wide equipment range','Solutions for contractors, projects and industrial requirements.'),
    const Feature(Icons.support_agent_rounded,'Responsive service','Direct access to our team for product and sales enquiries.'),
    const SizedBox(height:12),
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
      borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF20121A),panel])),
      child:const Row(children:[Icon(Icons.shield_rounded,color:red,size:45),SizedBox(width:15),
        Expanded(child:Text('GULF FIRE SHIELD\nTRADING FZE',style:TextStyle(fontWeight:FontWeight.w900,height:1.35)))])
    )
  ]));
}
class Feature extends StatelessWidget {
  final IconData icon; final String title,text;
  const Feature(this.icon,this.title,this.text,{super.key});
  @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(17),
    decoration:BoxDecoration(color:Colors.white.withOpacity(.045),borderRadius:BorderRadius.circular(21),border:Border.all(color:Colors.white.withOpacity(.07))),
    child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(icon,color:red,size:29),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:5),
        Text(text,style:TextStyle(color:Colors.white.withOpacity(.55),height:1.4))
      ]))
    ]));
}

class Contact extends StatelessWidget {
  const Contact({super.key});
  @override Widget build(BuildContext context)=>Page(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const SizedBox(height:5),const Tag('CONTACT US'),const SizedBox(height:16),
    const Text('Let’s talk\nabout your project.',style:TextStyle(fontSize:36,fontWeight:FontWeight.w900,height:1.04)),
    const SizedBox(height:12),Text('Reach Gulf Fire Shield directly.',style:TextStyle(color:Colors.white.withOpacity(.58))),
    const SizedBox(height:24),
    ContactTile(Icons.chat_rounded,'WhatsApp','+971 54 446 2358','https://wa.me/971544462358'),
    ContactTile(Icons.email_outlined,'General enquiries','info@gulffireshieldtrading.com','mailto:info@gulffireshieldtrading.com'),
    ContactTile(Icons.mark_email_read_outlined,'Sales','sales@gulffireshieldtrading.com','mailto:sales@gulffireshieldtrading.com'),
    ContactTile(Icons.language_rounded,'Website','www.gulffireshieldtrading.com','https://www.gulffireshieldtrading.com'),
    const SizedBox(height:8),
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:blue.withOpacity(.07),borderRadius:BorderRadius.circular(24),border:Border.all(color:blue.withOpacity(.17))),
      child:const Row(children:[Icon(Icons.location_on_rounded,color:blue,size:31),SizedBox(width:13),
        Expanded(child:Text('United Arab Emirates\nGulf Fire Shield Trading FZE',style:TextStyle(fontWeight:FontWeight.w700,height:1.4)))])
    )
  ]));
}
class ContactTile extends StatelessWidget {
  final IconData icon; final String title,value,url;
  const ContactTile(this.icon,this.title,this.value,this.url,{super.key});
  @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(16),
    decoration:BoxDecoration(color:Colors.white.withOpacity(.045),borderRadius:BorderRadius.circular(22),border:Border.all(color:Colors.white.withOpacity(.07))),
    child:Row(children:[
      Container(width:48,height:48,decoration:BoxDecoration(color:red.withOpacity(.11),shape:BoxShape.circle),child:Icon(icon,color:red)),
      const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:4),
        Text(value,maxLines:2,overflow:TextOverflow.ellipsis,style:TextStyle(color:Colors.white.withOpacity(.55),fontSize:12))
      ])),
      IconButton(onPressed:()=>openUrl(url),icon:const Icon(Icons.arrow_forward_rounded),color:red)
    ]));
}
