# Gulf Fire Shield — Final Design Build

Premium Flutter mobile app design for Gulf Fire Shield Trading FZE.

Included:
- Animated particle/glow background
- Animated hero entrance
- Mobile bottom navigation
- Home dashboard and metrics
- 11 product categories
- Interactive product cards and enquiry action
- About Us
- Contact actions for WhatsApp, general email, sales email and website
- Uploaded Gulf Fire Shield logo

Build commands:
flutter pub get
flutter run

APK:
flutter build apk --release
